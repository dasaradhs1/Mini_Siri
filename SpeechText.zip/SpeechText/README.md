# SpeechText
A programming assignment
